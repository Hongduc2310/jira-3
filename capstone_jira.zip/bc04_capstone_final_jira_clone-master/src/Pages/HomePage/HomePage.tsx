import React from "react";

const HomePage = () => {
  return <div>Home</div>;
};

export default HomePage;
