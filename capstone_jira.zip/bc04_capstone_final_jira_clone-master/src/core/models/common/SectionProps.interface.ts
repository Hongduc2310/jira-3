export interface SectionProps {
    title?: React.ReactNode,
    subTitle?:React.ReactNode,
    content?:React.ReactNode,
    sectionClass?: string
    titleClass?:string,
    contentClass?:string,
}